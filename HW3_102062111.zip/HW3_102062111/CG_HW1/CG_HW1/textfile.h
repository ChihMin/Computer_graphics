#pragma once
char *textFileRead(char *fn);
int textFileWrite(char *fn, char *s);
